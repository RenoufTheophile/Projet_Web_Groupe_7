<?php

echo"<h1>BDE</h1>";
echo"<h1>$_SESSION[username]</h1>";
echo"<h1>$_SESSION[connected]</h1>";
echo"<h1>$_SESSION[role]</h1>";
echo"<h1>$_SESSION[id]</h1>";

?>
